# Atlas external integrations

This beta contains app-side adapter status reporting only. It does not bundle a jailbreak, bootstrap, injector, or exploit.

## HookKit

Upstream: https://github.com/jjolano/HookKit

HookKit is a C-first hooking runtime intended for jailbreak-side consumers. Its upstream project documents separate rootful, rootless, and RootHide package lanes. The app uses `canImport(HookKit)` only as a build-time availability check. A positive result means the module is visible to the compiler; it does **not** mean a runtime exists, a target process is hooked, or the device is jailbroken. No HookKit runtime functions are called by this app.

To add a real consumer later, create a separate jailbreak-side target/package with the correct HookKit lane and keep it separate from this sandboxed dashboard target. Do not add guessed binary frameworks or pretend a normal IPA can activate the runtime.

## Procursus

Upstream: https://github.com/ProcursusTeam/Procursus

Procursus is an external bootstrap/package environment. It is not a Swift framework dependency. This app cannot install it. Because the iOS app sandbox prevents reliable inspection of the relevant system locations, the dashboard reports it as `Unverified` until a separately installed, trusted companion can provide status.

## RootHide

Upstream: https://github.com/roothide/Bootstrap

RootHide is a separate bootstrap ecosystem. Keep its adapter and any future companion protocol separate from Procursus. This app cannot install it or establish its presence from its sandbox. The dashboard therefore reports `Unverified`.

## Future status bridge

A future companion can expose a narrow, read-only status document over an explicitly configured and authenticated app-group or IPC channel. The document should include the component version, bootstrap lane, supported OS range, and a freshness timestamp. Until that protocol is implemented and authenticated, Atlas must not promote external components to `Available`.
