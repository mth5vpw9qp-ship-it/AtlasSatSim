# Project Atlas — AtlasSatSim Beta

AtlasSatSim is an iOS 16+ SwiftUI dashboard and local satellite-flow simulator. It is not a jailbreak and does not interact with CommCenter, satellite hardware, emergency services, Find My, or system processes.

## Build

Open `AtlasSatSim.xcodeproj` with Xcode, select the shared `AtlasSatSim` scheme, and build for a simulator or generic iOS device. Bundle ID: `org.projectatlas.satsim`; Swift 5. Device architecture reports arm64 generically and does not assert arm64e or jailbreak support.

Unsigned CI archive: push to `main` or run **Actions → Build unsigned IPA → Run workflow**. Download `AtlasSatSim-unsigned-ipa` from the completed run's artifacts. It must be signed separately before installation. No IPA is included in this source archive.

## Architecture and status

- **Atlas Core:** local device model, OS version, and compile architecture diagnostics. Available; diagnostics only.
- **Satellite Simulator:** four scripted local scenarios (Emergency SOS, roadside assistance, Find My location, connectivity unavailable). Simulation only; output explicitly states that nothing was transmitted.
- **HookKit adapter:** compile-time module availability check using `canImport(HookKit)`. If the module is visible, Atlas reports it as uninitialized; it does not create a HookKit runtime or install hooks. HookKit is a jailbreak-side hooking framework, not an app-side jailbreak or bootstrap.
- **Procursus adapter:** explicit external-bootstrap status. Procursus is a package/bootstrap environment; a sandboxed app cannot install it or reliably verify its presence.
- **RootHide adapter:** separate external-bootstrap status. RootHide is kept as its own lane and is never merged with a Procursus install. The app cannot install or reliably verify it.
- **Kernel mechanism:** unverified; none implemented.

No exploit, privilege escalation, PAC/SPTM bypass, process injection, or jailbreak state detection is implemented. iOS 27.0 on A16 remains experimental and unverified. No jailbreak bootstrap or hooking runtime is bundled. The adapter layer is intentionally read-only and reports what this app can establish without claiming that external jailbreak components are active.

## External integration references

- HookKit: https://github.com/jjolano/HookKit — C-first hooking runtime with distinct rootful, rootless, and RootHide package lanes. Atlas currently checks only whether a HookKit module is available to the compiler; it does not call the runtime API.
- Procursus: https://github.com/ProcursusTeam/Procursus — external bootstrap/package build system. Atlas does not bundle or install it.
- RootHide Bootstrap: https://github.com/roothide/Bootstrap — separate bootstrap project. Atlas does not bundle or install it.

A future jailbreak-side companion/tweak target can implement authenticated, read-only status reporting to Atlas. That communication channel is not implemented in this beta, so Procursus and RootHide remain `Unverified` in the app.

## CI and limitations

GitHub Actions uses a hosted macOS runner and Xcode to archive with code signing disabled, places the app under `Payload/AtlasSatSim.app`, creates `AtlasSatSim-unsigned.ipa`, and uploads it for seven days. The workflow does not sign the app. This workspace is not macOS, so compilation is unverified until CI succeeds.
